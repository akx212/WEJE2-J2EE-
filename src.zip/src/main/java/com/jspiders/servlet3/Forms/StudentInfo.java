package com.jspiders.servlet3.Forms;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentInfo
 */
@WebServlet("/nformation")
public class StudentInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Connection connection;
	private static PreparedStatement statement;
	private static String query;
	private static int result;
	private static String driverpath="com.mysql.cj.jdbc.Driver";
//	private static String dburl="jdbc:mysql://localhost:3306/weje2","root","root";
	      
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentInfo() {
        super();   
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			Class.forName(driverpath);
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/weje2","root","root");
			query="insert into student1 values(?,?,?,?,?,?,?)";
			
			statement=connection.prepareStatement(query);
			
			statement.setString(1, request.getParameter("fname"));
			statement.setString(2, request.getParameter("lname"));
			statement.setString(3, request.getParameter("dob"));
			statement.setString(4, request.getParameter("email"));
			statement.setString(5, request.getParameter("contact"));
			statement.setString(6, request.getParameter("city"));
			statement.setString(7, request.getParameter("gender"));
			
			result = statement.executeUpdate();
			response.setContentType("text/html");
			PrintWriter writer = response.getWriter();
			
			String name = request.getParameter("fname");
			writer.println("<h1>" + request.getParameter("fname"));
			writer.println("<h1>" + request.getParameter("lname"));
			writer.println("<h1>" + request.getParameter("dob"));
			writer.println("<h1>" + request.getParameter("email"));
			writer.println("<h1>" + request.getParameter("contact"));
			writer.println("<h1>" + request.getParameter("city"));
			writer.println("<h1>" + request.getParameter("gender"));
			
	//		request.getParameter("Details Save in Database" + driverpath);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();	
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
//	   response.setContentType("text/html");
//	   PrintWriter writer = response.getWriter();
//	   String name = request.getParameter("name");
//	   writer.println("<h1> My information" + name + "</h1>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
	}

}

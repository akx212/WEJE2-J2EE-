package com.task1;

public class Task {

}

package com.jspiders.designpattern.main;

import com.jspiders.designpattern.object.SingletonEager;

public class EagerMain {

	public static void main(String[] args) {
		SingletonEager.getObject();
		SingletonEager.getObject();
		SingletonEager.getObject();
		SingletonEager.getObject();
		SingletonEager.getObject();

	}

}

package com.jspiders.designpattern.main;

import com.jspiders.designpattern.object.SingletonLazy;

public class LazyMain {

	public static void main(String[] args) {
	   SingletonLazy.getObject();
	   SingletonLazy.getObject();
	   SingletonLazy.getObject();
	   SingletonLazy.getObject();
	   SingletonLazy.getObject();
	   

	}

}

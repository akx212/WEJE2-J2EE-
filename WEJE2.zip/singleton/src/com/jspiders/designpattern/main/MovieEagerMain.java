package com.jspiders.designpattern.main;

import com.jspiders.designpattern.object.MovieEager;

public class MovieEagerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        MovieEager.bookTickets(30);
        MovieEager.bookTickets(50);
        MovieEager.bookTickets(40);
	}

}

package com.jspiders.jdbc4.insert;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.jspiders.jdbc4.entity.Student;

public class JdbcInsert {

	private static Connection connection;
	private static PreparedStatement preparedStatememt;
	private static int result;
	private static Properties properties = new Properties();
	private static FileReader fileReader;
	private static String filePath ="E:\\WEJE2\\Jdbc3\\resources\\db_info.properties";
	private static String query;
	
	public static void main(String[] args) {
		try {
			fileReader = new FileReader(filePath);
			properties.load(fileReader);
			
			Class.forName(properties.getProperty("driverPath"));
			connection = DriverManager.getConnection(properties.getProperty("dburl"), properties);
			
			query="insert into student values(?,?,?)";
			preparedStatememt=connection.prepareStatement(query);
			preparedStatememt.setInt(1,1);
			preparedStatememt.setString(2, "undertaker");
			preparedStatememt.setString(3, "man@wwe.com");
			result=preparedStatememt.executeUpdate();
			System.out.println(result+ "row(s) inserted");
			
//			while(resultSet.next()) {
//				Student student= new Student();
//				student.setId(resultSet.getInt(1));
//				student.setName(resultSet.getString(2));
//				student.setEmail(resultSet.getString(3));
//				
//				System.out.println(student);
//			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (preparedStatememt != null) {
				try {
					preparedStatememt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
//			if (resultSet != null) {
//				try {
//					resultSet.close();
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
//			}
		}
}
}

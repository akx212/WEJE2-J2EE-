package com.jspiders.fastfood.food;

import com.jspiders.fastfood.inter.FastFood;

public class Pizza  implements FastFood{

	@Override
	public void orderFood() {
		
		System.out.println("Customer Order Pizza");
		
	}

}

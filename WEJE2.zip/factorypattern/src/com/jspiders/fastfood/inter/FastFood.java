package com.jspiders.fastfood.inter;

public interface FastFood {
	
    void orderFood();
}

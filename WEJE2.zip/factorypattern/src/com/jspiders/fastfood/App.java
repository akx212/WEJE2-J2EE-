package com.jspiders.fastfood;

public class App {

}

package com.jspiders.factorypattern.inter;

public interface Movie {
    void nowPlaying();
}

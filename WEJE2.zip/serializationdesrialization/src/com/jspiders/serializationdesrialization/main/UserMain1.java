package com.jspiders.serializationdesrialization.main;

public class UserMain1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

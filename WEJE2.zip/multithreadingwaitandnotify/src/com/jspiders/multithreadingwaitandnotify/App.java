package com.jspiders.multithreadingwaitandnotify;

public class App {

}
